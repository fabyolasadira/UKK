
-- Buat Database
CREATE DATABASE IF NOT EXISTS data_barang;
USE data_barang;

-- Tabel Kategori
CREATE TABLE kategori (
    id_kategori INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(100) NOT NULL
);

-- Tabel Barang
CREATE TABLE barang (
    ID_Barang INT AUTO_INCREMENT PRIMARY KEY,
    Nama_Barang VARCHAR(100) NOT NULL,
    Kategori_Barang INT,
    Jumlah_Stok INT NOT NULL CHECK (jumlah_stok >= 0),
    Harga_Barang INT NOT NULL CHECK (harga_barang >= 0),
    Tanggal_Masuk DATE NOT NULL,
    FOREIGN KEY (kategori_id) REFERENCES kategori(id_kategori)
);

-- Data Awal Kategori
INSERT INTO kategori (nama_kategori) VALUES
('Elektronik'),
('Furnitur');

-- Data Awal Barang
INSERT INTO barang (Nama_Barang, Kategori_Barang, Jumlah_Stok, Harga_Barang, Tanggal_Masuk) VALUES
('Laptop Acer', 1, 5, 10000000, '2025-01-16');
