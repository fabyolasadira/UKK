<nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
  <div class="container">
    <div class="navbar-nav">
      <a class="nav-link" href="index.php">Nama Barang</a>
      <a class="nav-link" href="kategori.php">Kategori Barang</a>
      <a class="nav-link" href="tambah.php">Tambah Barang</a>
    </div>
  </div>
</nav>